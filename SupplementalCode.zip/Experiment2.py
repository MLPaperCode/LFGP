###############################################################################
# Experiment2 (correspoding to Figure3)
###############################################################################
# Tuning of LFGP and RF
# training: 2017/4/1-2018/3/31, test:2018/4/1-2019/3/31 
# alpha=0.4
# LFGP profit=468 (d=10, n_min=100)
# LFGP profit=685 (d=10, n_min=200)
# LFGP profit=479 (d=10, n_min=300)
# LFGP profit=492 (d=30, n_min=100)
# LFGP profit=-357 (d=30, n_min=200) 
# LFGP profit=1357 (d=30, n_min=300) 
# LFGP profit=146 (d=50, n_min=100)
# LFGP profit=1304 (d=50, n_min=200)
# LFGP profit=179 (d=50, n_min=300)
# beta=0.48
# RF profit=966 (d=10, max_depth=5)
# RF profit=770 (d=10, max_depth=10)
# RF profit=-135 (d=10, max_depth=15)
# RF profit=289 (d=30, max_depth=5)
# RF profit=705 (d=30, max_depth=10)
# RF profit=157 (d=30, max_depth=15)
# RF profit=94 (d=50, max_depth=5)
# RF profit=405 (d=50, max_depth=10)
# RF profit=523 (d=50, max_depth=15)
###############################################################################
model = "RF" # "LFGP", "RF"
instrument = "GBP_JPY" 
start_train = '2018-04-01 00:00:00' 
end_train = '2019-04-01 00:00:00' 
start_test = '2019-04-01 00:00:00' 
end_test = '2020-04-01 00:00:00' 
d = 10 
n_min = 300 # LFGP
max_depth = 5 # RF
alpha_list = [0.5, 0.45, 0.4]
beta_list = [0.5, 0.49, 0.48]
c_list1 = ['red', 'blue', 'green']
c_list2 = ['deepskyblue', 'lightgreen', 'chocolate']
###############################################################################

import matplotlib.pyplot as plt
import seaborn as sns
from info import get_info
from BO import BinaryOption

ID, token = get_info()
BO = BinaryOption(ID, token, instrument, d=d)
BO.get_data(start_train, end_train, start_test, end_test)
if model == "LFGP":
    BO.LFGP_train(n_min)
    for i, alpha in enumerate(alpha_list):
        profit = BO.LFGP_test(alpha)
        sns.set()
        plt.plot(profit, c=c_list1[i], label='α = {:.2f}'.format(alpha))
        print('profit:', profit[-1])
    plt.legend(frameon=True, facecolor='white')
    plt.xlabel('Counts')
    plt.ylabel('Comulative Profit')    
    plt.xlim(0, 100000)
    plt.ylim(-350, 1850)
    plt.title('LFGP')
    plt.savefig('./LFGP.eps')
elif model == "RF":
    BO.RF_train(max_depth)
    for i, beta in enumerate(beta_list):
        profit = BO.RF_test(beta)
        sns.set()
        plt.plot(profit, c=c_list2[i], label='β = {:.2f}'.format(beta))
        print('profit:', profit[-1])
    plt.legend(frameon=True, facecolor='white')
    plt.xlabel('Counts')
    plt.ylabel('Comulative Profit')    
    plt.xlim(0, 100000)
    plt.ylim(-350, 1850)
    plt.title('RF')
    plt.savefig('./RF.eps')
plt.show()